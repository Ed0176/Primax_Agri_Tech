package com.example.primaxapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
